#!/usr/bin/env python3
"""
MCP Server que expõe chamados de suporte, no formato do GLPI.

Base dos chamados: chamados.json.

Protocolo MCP sobre stdio, JSON-RPC 2.0, sem dependência externa.

Teste manual:
    echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python3 server.py
"""

import json
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
CHAMADOS = json.load(open(os.path.join(AQUI, "chamados.json"), encoding="utf-8"))

PROTOCOLO = "2024-11-05"

FERRAMENTAS = [
    {
        "name": "listar_chamados",
        "description": (
            "Lista os chamados abertos no GLPI, do mais recente para o mais antigo. "
            "Retorna id, título, status, prioridade e categoria — sem o corpo do "
            "chamado. Use buscar_chamado para ler a descrição completa."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filtra por situação: aberto, em atendimento ou fechado.",
                    "enum": ["aberto", "em atendimento", "fechado"],
                },
                "categoria": {
                    "type": "string",
                    "description": "Filtra por categoria, ex: 'Acadêmico > Matrícula'.",
                },
                "limite": {
                    "type": "integer",
                    "description": "Máximo de chamados a retornar (padrão 20).",
                },
            },
        },
    },
    {
        "name": "buscar_chamado",
        "description": (
            "Retorna um chamado completo pelo número, incluindo a descrição do "
            "solicitante e todos os acompanhamentos."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "integer", "description": "Número do chamado, ex: 1234."}
            },
            "required": ["id"],
        },
    },
    {
        "name": "buscar_chamados_por_texto",
        "description": (
            "Busca chamados cujo título, descrição ou acompanhamentos contenham o "
            "termo informado. Útil para achar chamados relacionados a um sintoma."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "termo": {"type": "string", "description": "Texto a procurar."},
                "limite": {"type": "integer", "description": "Máximo de resultados (padrão 10)."},
            },
            "required": ["termo"],
        },
    },
    {
        "name": "adicionar_acompanhamento",
        "description": (
            "Registra um novo acompanhamento em um chamado. Use para documentar o "
            "que foi apurado, o resultado de uma conferência, ou o encaminhamento "
            "dado ao chamado."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "integer", "description": "Número do chamado."},
                "texto": {"type": "string", "description": "Conteúdo do acompanhamento."},
            },
            "required": ["id", "texto"],
        },
    },
]


def _resumo(c):
    return {k: c[k] for k in ("id", "titulo", "status", "prioridade", "categoria", "atualizacao")}


def _publico(c):
    """Remove campos internos do material didático antes de devolver ao agente."""
    return {k: v for k, v in c.items() if not k.startswith("_")}


def listar_chamados(status=None, categoria=None, limite=20):
    r = CHAMADOS
    if status:
        r = [c for c in r if c["status"] == status]
    if categoria:
        r = [c for c in r if categoria.lower() in c["categoria"].lower()]
    r = sorted(r, key=lambda c: c["atualizacao"], reverse=True)[: limite or 20]
    return [_resumo(c) for c in r]


def buscar_chamado(id):
    for c in CHAMADOS:
        if c["id"] == id:
            return _publico(c)
    return {"erro": f"chamado {id} não encontrado"}


def buscar_chamados_por_texto(termo, limite=10):
    t = (termo or "").lower()
    achados = []
    for c in CHAMADOS:
        corpo = " ".join([c["titulo"], c["descricao"], *c.get("acompanhamentos", [])]).lower()
        if t in corpo:
            achados.append(_resumo(c))
    return achados[: limite or 10]


def adicionar_acompanhamento(id, texto):
    for c in CHAMADOS:
        if c["id"] == id:
            c.setdefault("acompanhamentos", []).append(texto)
            with open(os.path.join(AQUI, "chamados.json"), "w", encoding="utf-8") as f:
                json.dump(CHAMADOS, f, ensure_ascii=False, indent=2)
                f.write("\n")
            return {"ok": True, "id": id, "total_acompanhamentos": len(c["acompanhamentos"])}
    return {"erro": f"chamado {id} não encontrado"}


IMPL = {
    "listar_chamados": listar_chamados,
    "buscar_chamado": buscar_chamado,
    "buscar_chamados_por_texto": buscar_chamados_por_texto,
    "adicionar_acompanhamento": adicionar_acompanhamento,
}


def responder(id_, resultado=None, erro=None):
    msg = {"jsonrpc": "2.0", "id": id_}
    if erro is not None:
        msg["error"] = erro
    else:
        msg["result"] = resultado
    sys.stdout.write(json.dumps(msg, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def tratar(msg):
    metodo = msg.get("method")
    id_ = msg.get("id")

    if metodo == "initialize":
        return responder(id_, {
            "protocolVersion": PROTOCOLO,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "glpi-mock", "version": "1.0.0"},
        })

    if metodo in ("notifications/initialized", "initialized"):
        return  # notificação: sem resposta

    if metodo == "ping":
        return responder(id_, {})

    if metodo == "tools/list":
        return responder(id_, {"tools": FERRAMENTAS})

    if metodo == "tools/call":
        p = msg.get("params") or {}
        nome = p.get("name")
        args = p.get("arguments") or {}
        fn = IMPL.get(nome)
        if not fn:
            return responder(id_, erro={"code": -32601, "message": f"ferramenta desconhecida: {nome}"})
        try:
            saida = fn(**args)
        except TypeError as e:
            return responder(id_, erro={"code": -32602, "message": f"argumentos inválidos: {e}"})
        return responder(id_, {
            "content": [{"type": "text", "text": json.dumps(saida, ensure_ascii=False, indent=2)}]
        })

    if id_ is not None:
        responder(id_, erro={"code": -32601, "message": f"método não suportado: {metodo}"})


def main():
    for linha in sys.stdin:
        linha = linha.strip()
        if not linha:
            continue
        try:
            tratar(json.loads(linha))
        except json.JSONDecodeError:
            continue


if __name__ == "__main__":
    main()
