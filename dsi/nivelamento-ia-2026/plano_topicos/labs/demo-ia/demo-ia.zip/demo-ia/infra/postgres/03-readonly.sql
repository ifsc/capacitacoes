-- Usuário read-only para o MCP de banco.
--
-- O agente se conecta com ESTE usuário, não com o dono do schema: um DELETE
-- disparado por ele falha por permissão, não por boa vontade.

CREATE USER agente_readonly WITH PASSWORD 'somente_leitura';

GRANT CONNECT ON DATABASE sigaa_demo TO agente_readonly;
GRANT USAGE   ON SCHEMA public       TO agente_readonly;

GRANT SELECT ON ALL TABLES IN SCHEMA public TO agente_readonly;

-- Vale também para tabelas criadas depois.
ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT SELECT ON TABLES TO agente_readonly;

-- Explicitamente negado. Redundante — o usuário nunca teve esses direitos —
-- mas serve de documentação executável da intenção.
REVOKE INSERT, UPDATE, DELETE, TRUNCATE
    ON ALL TABLES IN SCHEMA public FROM agente_readonly;
