-- Esquema do domínio de ingresso/acadêmico:
-- oferta -> candidatos aprovados -> matrícula.

CREATE TABLE curso (
    id           BIGSERIAL PRIMARY KEY,
    codigo       VARCHAR(20)  NOT NULL UNIQUE,
    nome         VARCHAR(120) NOT NULL,
    campus       VARCHAR(60)  NOT NULL,
    modalidade   VARCHAR(30)  NOT NULL,   -- integrado, subsequente, superior
    turno        VARCHAR(20)  NOT NULL,
    vagas_totais INTEGER      NOT NULL
);

CREATE TABLE candidato (
    id          BIGSERIAL PRIMARY KEY,
    cpf         VARCHAR(11)  NOT NULL UNIQUE,
    nome        VARCHAR(120) NOT NULL,
    email       VARCHAR(120) NOT NULL,
    nascimento  DATE         NOT NULL
);

CREATE TABLE oferta (
    id             BIGSERIAL PRIMARY KEY,
    id_curso       BIGINT       NOT NULL REFERENCES curso(id),
    numero_chamada INTEGER      NOT NULL,
    semestre       VARCHAR(6)   NOT NULL,   -- ex: 2026.1
    data_resultado TIMESTAMP    NOT NULL,
    situacao       VARCHAR(20)  NOT NULL,   -- publicada, encerrada
    UNIQUE (id_curso, numero_chamada, semestre)
);

CREATE TABLE candidatos_aprovados (
    id            BIGSERIAL PRIMARY KEY,
    id_chamada    BIGINT      NOT NULL REFERENCES oferta(id),
    id_candidato  BIGINT      NOT NULL REFERENCES candidato(id),
    classificacao INTEGER     NOT NULL,
    situacao      VARCHAR(20) NOT NULL,     -- aprovado, desistente
    UNIQUE (id_chamada, id_candidato)
);

CREATE TABLE matricula (
    id             BIGSERIAL PRIMARY KEY,
    id_candidato   BIGINT      NOT NULL REFERENCES candidato(id),
    id_curso       BIGINT      NOT NULL REFERENCES curso(id),
    id_chamada     BIGINT      NOT NULL REFERENCES oferta(id),
    matricula      VARCHAR(20) NOT NULL UNIQUE,
    data_matricula TIMESTAMP   NOT NULL,
    situacao       VARCHAR(20) NOT NULL,    -- ativa, trancada, cancelada
    -- Idempotência por chave natural: o mesmo candidato não pode ser
    -- matriculado duas vezes na mesma chamada.
    UNIQUE (id_candidato, id_chamada)
);

CREATE INDEX idx_matricula_curso       ON matricula (id_curso);
CREATE INDEX idx_matricula_situacao    ON matricula (situacao);
CREATE INDEX idx_candidatos_aprovados  ON candidatos_aprovados (id_chamada);
CREATE INDEX idx_oferta_curso          ON oferta (id_curso, semestre);

COMMENT ON TABLE  curso                IS 'Cursos ofertados por campus';
COMMENT ON TABLE  oferta               IS 'Cada convocação de aprovados de um processo seletivo';
COMMENT ON TABLE  candidatos_aprovados IS 'Candidatos convocados em uma chamada';
COMMENT ON TABLE  matricula            IS 'Vínculo efetivado do candidato com o curso';
COMMENT ON COLUMN matricula.situacao IS 'ativa | trancada | cancelada';
