-- Dados fictícios. O setseed torna a geração determinística: recriar o banco
-- devolve exatamente os mesmos registros.
-- Nenhum dado real de aluno ou servidor.

SELECT setseed(0.42);

INSERT INTO curso (codigo, nome, campus, modalidade, turno, vagas_totais) VALUES
 ('INFO-INT',  'Técnico em Informática',                'Florianópolis', 'integrado',   'matutino',  80),
 ('ELET-INT',  'Técnico em Eletrônica',                 'Florianópolis', 'integrado',   'matutino',  36),
 ('EDIF-INT',  'Técnico em Edificações',                'Florianópolis', 'integrado',   'vespertino',36),
 ('MECA-SUB',  'Técnico em Mecânica',                   'Jaraguá do Sul','subsequente', 'noturno',   30),
 ('QUIM-INT',  'Técnico em Química',                    'Criciúma',      'integrado',   'matutino',  32),
 ('ADM-SUB',   'Técnico em Administração',              'São José',      'subsequente', 'noturno',   40),
 ('AGRO-INT',  'Técnico em Agropecuária',               'Lages',         'integrado',   'integral',  30),
 ('ADS-SUP',   'Tecnologia em Análise e Desenvolvimento de Sistemas', 'Florianópolis', 'superior', 'noturno', 80),
 ('MECT-SUP',  'Engenharia Mecatrônica',                'Florianópolis', 'superior',    'integral',  30),
 ('GESTI-SUP', 'Tecnologia em Gestão da Tecnologia da Informação',    'São José', 'superior', 'noturno', 35),
 ('ENFE-SUB',  'Técnico em Enfermagem',                 'Joinville',     'subsequente', 'vespertino',30),
 ('REFR-SUB',  'Técnico em Refrigeração',               'São José',      'subsequente', 'noturno',   28);

-- ── Candidatos ───────────────────────────────────────────────────
INSERT INTO candidato (cpf, nome, email, nascimento)
SELECT
    LPAD((100000000 + n * 37)::text, 11, '0'),
    nomes.primeiro || ' ' || meio.parte || ' ' || sobrenomes.ultimo,
    LOWER(REPLACE(nomes.primeiro, ' ', '')) || '.' ||
        LOWER(sobrenomes.ultimo) || n || '@exemplo.edu.br',
    DATE '2001-01-01' + (n * 7 % 3200)
FROM generate_series(1, 900) AS n
CROSS JOIN LATERAL (SELECT (ARRAY[
    'Ana','Bruno','Carla','Diego','Eduarda','Felipe','Gabriela','Henrique',
    'Isabela','João','Karina','Lucas','Mariana','Nicolas','Otávio','Patrícia',
    'Rafael','Sabrina','Thiago','Vitória','Camila','Douglas','Elisa','Fernando'
])[1 + (n * 11) % 24] AS primeiro) AS nomes
CROSS JOIN LATERAL (SELECT (ARRAY[
    'de','dos','da','','','Luiz','Maria','Cristina','Augusto'
])[1 + (n * 5) % 9] AS parte) AS meio
CROSS JOIN LATERAL (SELECT (ARRAY[
    'Silva','Souza','Oliveira','Schmitt','Kruger','Pereira','Machado','Bittencourt',
    'Nunes','Fernandes','Koerich','Amorim','Cardoso','Vieira','Hoffmann','Rocha'
])[1 + (n * 7) % 16] AS ultimo) AS sobrenomes;

-- ── Ofertas ──────────────────────────────────────────────────────
-- 2025.2 encerrada, 2026.1 com 1ª e 2ª oferta publicadas.
INSERT INTO oferta (id_curso, numero_chamada, semestre, data_resultado, situacao)
SELECT c.id, 1, '2025.2', TIMESTAMP '2025-07-14 18:00', 'encerrada' FROM curso c;

INSERT INTO oferta (id_curso, numero_chamada, semestre, data_resultado, situacao)
SELECT c.id, 1, '2026.1', TIMESTAMP '2026-01-19 18:00', 'encerrada' FROM curso c;

INSERT INTO oferta (id_curso, numero_chamada, semestre, data_resultado, situacao)
SELECT c.id, 2, '2026.1', TIMESTAMP '2026-02-09 18:00', 'publicada' FROM curso c;

-- ── Aprovados ────────────────────────────────────────────────────
-- Cada oferta convoca um número de candidatos proporcional às vagas.
INSERT INTO candidatos_aprovados (id_chamada, id_candidato, classificacao, situacao)
SELECT
    ch.id,
    cand.id,
    ROW_NUMBER() OVER (PARTITION BY ch.id ORDER BY cand.id),
    CASE WHEN (cand.id * 13 + ch.id) % 11 = 0 THEN 'desistente' ELSE 'aprovado' END
FROM oferta ch
JOIN curso cu ON cu.id = ch.id_curso
JOIN LATERAL (
    SELECT id FROM candidato
    ORDER BY (id * 17 + ch.id * 31) % 900
    LIMIT CASE WHEN ch.numero_chamada = 1
               THEN cu.vagas_totais
               ELSE GREATEST(cu.vagas_totais / 3, 6) END
) cand ON TRUE;

-- ── Matrículas ───────────────────────────────────────────────────
-- Só as ofertas encerradas geraram matrícula. A 2ª oferta de 2026.1
-- está publicada e ainda não foi processada.
INSERT INTO matricula (id_candidato, id_curso, id_chamada, matricula, data_matricula, situacao)
SELECT
    ap.id_candidato,
    ch.id_curso,
    ch.id,
    ch.semestre || LPAD(ch.id_curso::text, 2, '0') ||
        LPAD(ROW_NUMBER() OVER (PARTITION BY ch.id ORDER BY ap.classificacao)::text, 4, '0'),
    ch.data_resultado + INTERVAL '3 days',
    CASE
        WHEN (ap.id_candidato * 7) % 23 = 0 THEN 'cancelada'
        WHEN (ap.id_candidato * 7) % 19 = 0 THEN 'trancada'
        ELSE 'ativa'
    END
FROM candidatos_aprovados ap
JOIN oferta ch ON ch.id = ap.id_chamada
WHERE ch.situacao = 'encerrada'
  AND ap.situacao  = 'aprovado';

ANALYZE;
