#!/usr/bin/env bash
# Sobe tudo: banco, build do frontend e backend servindo os dois.
# Uso: ./subir.sh          (build + run)
#      ./subir.sh --q (pula o build do frontend)
set -euo pipefail
cd "$(dirname "$0")"


VER=$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/')
if ! [ "${VER:-0}" -ge 21 ] 2>/dev/null; then
  echo "✗ Este projeto precisa de Java 21. Encontrei: $(java -version 2>&1 | head -1)"
  echo
  echo "  Ubuntu/Debian:  sudo apt install openjdk-21-jdk"
  echo "  Ja instalado?   export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64"
  echo "  Conferir:       java -version && mvn -version | grep 'Java version'"
  exit 1
fi

echo "→ banco"
docker compose up -d
until docker exec demo-ia-postgres pg_isready -U sigaa -d sigaa_demo >/dev/null 2>&1; do sleep 2; done

if [ "${1:-}" != "--q" ]; then
  echo "→ frontend (build para backend/src/main/resources/static)"
  (cd frontend && npm install --no-audit --no-fund --silent && npx ng build)
fi

echo "→ backend em http://localhost:8080"
cd backend && mvn -B spring-boot:run
