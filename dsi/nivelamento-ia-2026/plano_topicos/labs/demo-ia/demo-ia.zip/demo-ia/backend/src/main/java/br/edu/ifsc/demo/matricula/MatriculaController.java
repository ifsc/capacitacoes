package br.edu.ifsc.demo.matricula;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/matriculas")
public class MatriculaController {

    private final MatriculaService service;

    public MatriculaController(MatriculaService service) {
        this.service = service;
    }

    @GetMapping("/curso/{idCurso}")
    public List<MatriculaResumo> porCurso(@PathVariable Long idCurso) {
        return service.listarPorCurso(idCurso);
    }
}
