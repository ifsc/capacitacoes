package br.edu.ifsc.demo.matricula;

import br.edu.ifsc.demo.candidato.CandidatoRepository;
import br.edu.ifsc.demo.oferta.OfertaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class MatriculaService {

    private final MatriculaRepository matriculas;
    private final CandidatoRepository candidatos;
    private final OfertaRepository ofertas;

    public MatriculaService(MatriculaRepository matriculas,
                            CandidatoRepository candidatos,
                            OfertaRepository ofertas) {
        this.matriculas = matriculas;
        this.candidatos = candidatos;
        this.ofertas = ofertas;
    }

    /**
     * Lista as matrículas de um curso com os dados do candidato e da oferta.
     */
    @Transactional(readOnly = true)
    public List<MatriculaResumo> listarPorCurso(Long idCurso) {
        var encontradas = matriculas.findByIdCurso(idCurso);

        var resultado = new ArrayList<MatriculaResumo>();
        for (var m : encontradas) {
            var candidato = candidatos.findById(m.getIdCandidato()).orElseThrow();
            var oferta = ofertas.findById(m.getIdChamada()).orElseThrow();

            resultado.add(new MatriculaResumo(
                    m.getId(),
                    m.getMatricula(),
                    candidato.getNome(),
                    candidato.getCpf(),
                    oferta.getSemestre(),
                    oferta.getNumeroChamada(),
                    m.getDataMatricula(),
                    m.getSituacao()));
        }
        return resultado;
    }
}
