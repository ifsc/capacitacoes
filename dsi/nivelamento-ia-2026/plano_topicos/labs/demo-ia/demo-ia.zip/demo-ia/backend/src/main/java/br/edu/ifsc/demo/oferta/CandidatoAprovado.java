package br.edu.ifsc.demo.oferta;

import jakarta.persistence.*;

@Entity
@Table(name = "candidatos_aprovados")
public class CandidatoAprovado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_chamada")
    private Long idChamada;

    @Column(name = "id_candidato")
    private Long idCandidato;

    private Integer classificacao;

    /** aprovado | desistente */
    private String situacao;

    public Long getId() { return id; }
    public Long getIdChamada() { return idChamada; }
    public Long getIdCandidato() { return idCandidato; }
    public Integer getClassificacao() { return classificacao; }
    public String getSituacao() { return situacao; }
}
