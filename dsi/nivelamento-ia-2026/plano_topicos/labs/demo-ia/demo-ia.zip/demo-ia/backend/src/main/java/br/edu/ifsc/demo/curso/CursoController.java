package br.edu.ifsc.demo.curso;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/cursos")
public class CursoController {

    private final CursoRepository cursos;

    public CursoController(CursoRepository cursos) {
        this.cursos = cursos;
    }

    @GetMapping
    public List<Curso> listar() {
        return cursos.findAll();
    }
}
