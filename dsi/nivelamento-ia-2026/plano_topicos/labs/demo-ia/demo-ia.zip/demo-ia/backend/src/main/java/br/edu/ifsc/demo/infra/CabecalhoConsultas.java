package br.edu.ifsc.demo.infra;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * Devolve a contagem no cabeçalho X-Consultas-SQL.
 *
 * Roda antes da serialização do corpo — nesse ponto o controller já executou,
 * então a contagem está fechada, e a resposta ainda não foi enviada.
 */
@ControllerAdvice
public class CabecalhoConsultas implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter retorno, Class<? extends HttpMessageConverter<?>> conversor) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object corpo, MethodParameter retorno, MediaType tipo,
                                  Class<? extends HttpMessageConverter<?>> conversor,
                                  ServerHttpRequest req, ServerHttpResponse res) {
        res.getHeaders().add("X-Consultas-SQL", String.valueOf(ContadorConsultas.total()));
        res.getHeaders().add("Access-Control-Expose-Headers", "X-Consultas-SQL");
        return corpo;
    }
}
