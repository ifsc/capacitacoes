package br.edu.ifsc.demo.candidato;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "candidato")
public class Candidato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String cpf;
    private String nome;
    private String email;
    private LocalDate nascimento;

    public Long getId() { return id; }
    public String getCpf() { return cpf; }
    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public LocalDate getNascimento() { return nascimento; }
}
