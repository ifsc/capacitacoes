package br.edu.ifsc.demo.infra;

import org.hibernate.resource.jdbc.spi.StatementInspector;

/**
 * Conta quantas consultas SQL uma única requisição dispara.
 *
 * Existe para tornar visível um problema que o tempo de resposta não mostra
 * de forma confiável: numa máquina rápida, com cache quente, uma consulta N+1
 * ainda responde em 100ms. O número de consultas, ao contrário, é
 * determinístico — não depende de máquina, de JIT nem de cache.
 */
public class ContadorConsultas implements StatementInspector {

    private static final ThreadLocal<Integer> CONTADOR = ThreadLocal.withInitial(() -> 0);

    @Override
    public String inspect(String sql) {
        CONTADOR.set(CONTADOR.get() + 1);
        return sql;
    }

    public static void zerar() {
        CONTADOR.set(0);
    }

    public static int total() {
        return CONTADOR.get();
    }

    public static void limpar() {
        CONTADOR.remove();
    }
}
