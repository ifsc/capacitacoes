package br.edu.ifsc.demo.infra;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/** Zera o contador no começo de cada requisição e limpa a thread no fim. */
@Component
public class FiltroContadorConsultas extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        ContadorConsultas.zerar();
        try {
            chain.doFilter(req, res);
        } finally {
            ContadorConsultas.limpar();
        }
    }
}
