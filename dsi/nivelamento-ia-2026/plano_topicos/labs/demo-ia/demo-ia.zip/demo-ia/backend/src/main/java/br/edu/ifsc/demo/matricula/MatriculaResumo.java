package br.edu.ifsc.demo.matricula;

import java.time.LocalDateTime;

/** Uma linha da listagem de matrículas de um curso. */
public record MatriculaResumo(
        Long id,
        String matricula,
        String nomeCandidato,
        String cpfCandidato,
        String semestre,
        Integer numeroChamada,
        LocalDateTime dataMatricula,
        String situacao) {
}
