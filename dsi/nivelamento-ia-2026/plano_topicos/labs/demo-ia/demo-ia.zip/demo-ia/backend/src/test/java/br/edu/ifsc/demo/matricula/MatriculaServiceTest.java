package br.edu.ifsc.demo.matricula;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class MatriculaServiceTest {

    @Autowired
    MatriculaService service;

    @Test
    void deveListarMatriculasQuandoCursoTemAlunos() {
        // curso 1 = Técnico em Informática
        var resultado = service.listarPorCurso(1L);

        assertThat(resultado).isNotEmpty();
        assertThat(resultado.getFirst().nomeCandidato()).isNotBlank();
        assertThat(resultado.getFirst().semestre()).isNotBlank();
    }

    @Test
    void deveRetornarVazioQuandoCursoNaoTemMatricula() {
        assertThat(service.listarPorCurso(9999L)).isEmpty();
    }
}
