package br.edu.ifsc.demo.oferta;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CandidatoAprovadoRepository extends JpaRepository<CandidatoAprovado, Long> {
    List<CandidatoAprovado> findByIdChamadaAndSituacao(Long idChamada, String situacao);
}
