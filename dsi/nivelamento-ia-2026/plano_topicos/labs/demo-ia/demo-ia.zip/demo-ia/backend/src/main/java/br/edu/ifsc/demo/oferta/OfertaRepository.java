package br.edu.ifsc.demo.oferta;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OfertaRepository extends JpaRepository<Oferta, Long> {
    List<Oferta> findBySemestreAndSituacao(String semestre, String situacao);
}
