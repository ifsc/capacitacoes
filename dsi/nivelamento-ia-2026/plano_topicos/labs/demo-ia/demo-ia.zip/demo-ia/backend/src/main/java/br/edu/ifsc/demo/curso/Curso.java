package br.edu.ifsc.demo.curso;

import jakarta.persistence.*;

@Entity
@Table(name = "curso")
public class Curso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String codigo;
    private String nome;
    private String campus;
    private String modalidade;
    private String turno;

    @Column(name = "vagas_totais")
    private Integer vagasTotais;

    public Long getId() { return id; }
    public String getCodigo() { return codigo; }
    public String getNome() { return nome; }
    public String getCampus() { return campus; }
    public String getModalidade() { return modalidade; }
    public String getTurno() { return turno; }
    public Integer getVagasTotais() { return vagasTotais; }
}
