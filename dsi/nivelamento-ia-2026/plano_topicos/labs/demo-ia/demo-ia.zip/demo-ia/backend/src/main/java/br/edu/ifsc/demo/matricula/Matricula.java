package br.edu.ifsc.demo.matricula;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "matricula")
public class Matricula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_candidato")
    private Long idCandidato;

    @Column(name = "id_curso")
    private Long idCurso;

    @Column(name = "id_chamada")
    private Long idChamada;

    private String matricula;

    @Column(name = "data_matricula")
    private LocalDateTime dataMatricula;

    /** ativa | trancada | cancelada */
    private String situacao;

    protected Matricula() { }

    public Matricula(Long idCandidato, Long idCurso, Long idChamada,
                     String matricula, LocalDateTime dataMatricula, String situacao) {
        this.idCandidato = idCandidato;
        this.idCurso = idCurso;
        this.idChamada = idChamada;
        this.matricula = matricula;
        this.dataMatricula = dataMatricula;
        this.situacao = situacao;
    }

    public Long getId() { return id; }
    public Long getIdCandidato() { return idCandidato; }
    public Long getIdCurso() { return idCurso; }
    public Long getIdChamada() { return idChamada; }
    public String getMatricula() { return matricula; }
    public LocalDateTime getDataMatricula() { return dataMatricula; }
    public String getSituacao() { return situacao; }
}
