package br.edu.ifsc.demo.oferta;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "oferta")
public class Oferta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "id_curso")
    private Long idCurso;

    @Column(name = "numero_chamada")
    private Integer numeroChamada;

    private String semestre;

    @Column(name = "data_resultado")
    private LocalDateTime dataResultado;

    /** publicada | encerrada */
    private String situacao;

    public Long getId() { return id; }
    public Long getIdCurso() { return idCurso; }
    public Integer getNumeroChamada() { return numeroChamada; }
    public String getSemestre() { return semestre; }
    public LocalDateTime getDataResultado() { return dataResultado; }
    public String getSituacao() { return situacao; }
}
