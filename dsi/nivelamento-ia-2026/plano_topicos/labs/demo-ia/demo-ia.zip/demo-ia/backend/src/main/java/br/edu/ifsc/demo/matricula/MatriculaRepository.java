package br.edu.ifsc.demo.matricula;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MatriculaRepository extends JpaRepository<Matricula, Long> {

    List<Matricula> findByIdCurso(Long idCurso);

    boolean existsByIdCandidatoAndIdChamada(Long idCandidato, Long idChamada);
}
