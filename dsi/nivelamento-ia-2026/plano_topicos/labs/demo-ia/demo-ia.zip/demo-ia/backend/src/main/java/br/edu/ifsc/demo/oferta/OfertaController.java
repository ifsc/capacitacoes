package br.edu.ifsc.demo.oferta;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/ofertas")
public class OfertaController {

    private final OfertaRepository ofertas;

    public OfertaController(OfertaRepository ofertas) {
        this.ofertas = ofertas;
    }

    @GetMapping
    public List<Oferta> listar(
            @RequestParam(defaultValue = "2026.1") String semestre,
            @RequestParam(required = false) String situacao) {
        return situacao == null
                ? ofertas.findAll().stream().filter(c -> c.getSemestre().equals(semestre)).toList()
                : ofertas.findBySemestreAndSituacao(semestre, situacao);
    }
}
