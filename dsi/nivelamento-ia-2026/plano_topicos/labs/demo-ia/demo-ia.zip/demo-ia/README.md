# Demo Acadêmico — Ingresso

Demonstração do seminário de nivelamento em IA, com domínio reduzido - SIGAA: **oferta → candidatos aprovados → matrícula**.

## Visão Geral

Sistema acadêmico que processa ofertas de vagas de um processo seletivo, rastreia candidatos aprovados e registra suas matrículas. O projeto demonstra como agentes de IA podem navegar em dados e tomar decisões em contexto acadêmico.

## Estrutura do Projeto

```
infra/postgres/     schema do banco, seed e usuário read-only do agente
infra/glpi-mock/    MCP Server que simula o GLPI (chamados fictícios)
backend/            serviço acadêmico (Spring Boot, Java 21)
frontend/           tela de acompanhamento (Angular)
docs/               decisões e detalhamento da arquitetura
```

## Conceitos Principais

- **Oferta**: Convocação de aprovados em um processo seletivo
  - Situações: `publicada` (resultado saiu) ou `encerrada` (já processada)
- **Candidatos Aprovados**: Candidatos convocados em uma oferta
  - Podem estar `desistente`
- **Matrícula**: Vínculo efetivado do candidato
  - Chave natural: `(id_candidato, id_chamada)` — garante idempotência
  - O mesmo candidato não pode ser matriculado duas vezes na mesma oferta

**Semestre corrente**: 2026.1

## Como Começar

### Pré-requisitos

- Docker e Docker Compose
- Java 21
- Node.js 18+ (para frontend)

### Subindo o Ambiente

```bash
# Inicia o banco de dados PostgreSQL
docker compose up -d

# O banco é populado automaticamente na primeira subida
```

### Resetando do Zero

```bash
# Remove volumes e recria tudo
docker compose down -v && docker compose up -d
```

## Arquitetura

- **Backend**: Spring Boot com camadas `controller` → `service` → `repository`
- **Frontend**: Angular com consumo de API versionada
- **Banco de Dados**: PostgreSQL com migrações numeradas

## Desenvolvendo

Consulte a documentação detalhada em:
- `AGENTS.md` — instruções técnicas e convenções
- `docs/` — decisões de arquitetura
