export interface Curso {
  id: number;
  codigo: string;
  nome: string;
  campus: string;
  modalidade: string;
  turno: string;
  vagasTotais: number;
}

export interface MatriculaResumo {
  id: number;
  matricula: string;
  nomeCandidato: string;
  cpfCandidato: string;
  semestre: string;
  numeroChamada: number;
  dataMatricula: string;
  situacao: string;
}

/** Em desenvolvimento o Angular roda em :4200 e o backend em :8080.
 *  Quando o front é servido pelo próprio Spring Boot, a origem é a mesma. */
export const API = location.port === '4200' ? 'http://localhost:8080' : '';
