import { Component, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { API, Curso, MatriculaResumo } from './api';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  cursos = signal<Curso[]>([]);
  matriculas = signal<MatriculaResumo[]>([]);
  cursoSelecionado = signal<Curso | null>(null);
  carregando = signal(false);
  tempoMs = signal<number | null>(null);
  consultas = signal<number | null>(null);

  ativas = computed(() => this.matriculas().filter(m => m.situacao === 'ativa').length);

  /** Uma consulta por matricula significa N+1. Com a busca corrigida sao poucas,
   *  independente do tamanho da lista. */
  temNMaisUm = computed(() => {
    const c = this.consultas();
    return c !== null && c >= this.matriculas().length;
  });

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get<Curso[]>(`${API}/api/v1/cursos`).subscribe(c => this.cursos.set(c));
  }

  selecionar(curso: Curso) {
    this.cursoSelecionado.set(curso);
    this.carregando.set(true);
    this.matriculas.set([]);
    const inicio = performance.now();
    this.http.get<MatriculaResumo[]>(`${API}/api/v1/matriculas/curso/${curso.id}`,
        { observe: 'response' })
      .subscribe({
        next: resp => {
          this.matriculas.set(resp.body ?? []);
          this.tempoMs.set(Math.round(performance.now() - inicio));
          // O backend conta quantas consultas SQL a requisicao disparou.
          // Diferente do tempo, esse numero nao varia com a maquina.
          const n = resp.headers.get('X-Consultas-SQL');
          this.consultas.set(n ? Number(n) : null);
          this.carregando.set(false);
        },
        error: () => this.carregando.set(false)
      });
  }
}
