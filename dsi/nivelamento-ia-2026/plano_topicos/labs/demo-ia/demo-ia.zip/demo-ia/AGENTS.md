# AGENTS.md — Demo Acadêmico / Ingresso

Projeto de demonstração do seminário de nivelamento em IA. Domínio reduzido do
SIGAA: **oferta → candidatos aprovados → matrícula**.

## Estrutura

```
infra/postgres/     schema, seed e o usuário read-only do agente
infra/glpi-mock/    MCP Server que simula o GLPI (chamados fictícios)
backend/            serviço acadêmico (Spring Boot, Java 21)
frontend/           tela de acompanhamento (Angular)
docs/               decisões e detalhamento
```

## Como subir

```bash
docker compose up -d          # Postgres em localhost:55432
```

O banco é populado automaticamente na primeira subida. Para recomeçar do zero:
`docker compose down -v && docker compose up -d`.


## Domínio — o que você precisa saber antes de mexer
- **`oferta`** é uma convocação de aprovados de um processo seletivo.
  Tem `situacao`: `publicada` (saiu o resultado) ou `encerrada` (já processada).
- **`candidatos_aprovados`** são os candidatos convocados naquela oferta. Um
  aprovado pode estar `desistente`.
- **`matricula`** é o vínculo efetivado. A chave natural é
  `(id_candidato, id_chamada)` — **é ela que garante idempotência**. O mesmo
  candidato não pode ser matriculado duas vezes na mesma oferta.
  A coluna continua `id_chamada`: só as tabelas foram renomeadas.
- Semestre corrente da base: **2026.1**. A 2ª oferta de 2026.1 está
  `publicada` e ainda **não** foi processada.

## Convenções

- Java 21, Spring Boot. Pacote raiz `br.edu.ifsc.demo`.
- Camadas: `controller` → `service` → `repository`. Regra de negócio no service,
  nunca no controller.
- DTO de entrada e saída sempre `record`. Nunca exponha entidade JPA na API.
- Rotas versionadas: `/api/v1/...`.
- Teste com JUnit 5 + AssertJ. Nome no padrão `deveFazerXQuandoY`.
- Migração de banco em `infra/postgres/` numerada (`04-...sql`, `05-...sql`).
  **Não** altere arquivos já aplicados — crie o próximo número.

## Acesso a dados pelo agente

O MCP `postgres` conecta com o usuário **`agente_readonly`**. Ele só faz
`SELECT`.

## MCPs configurados

| Servidor | Para quê |
| --- | --- |
| `glpi` | Ler chamados de suporte (mock local, dados fictícios) |
| `postgres` | Consultar o banco, somente leitura |
| `context7` | Documentação atualizada de biblioteca |
| `playwright` | Navegar na aplicação pelo browser |

## Armadilhas conhecidas

- `docker compose down` sem `-v` mantém o volume: alterações em
  `infra/postgres/*.sql` **não** são reaplicadas. Use `-v` para recriar.
